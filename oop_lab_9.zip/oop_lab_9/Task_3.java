public abstract class Shape{

public abstract double area();


} 
public interface Printable{
public void print();

}
public class Rectangle extends Shape implements Printable {
    private double width;
    private double height;

    Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }
public double area(){
return width*height;
}
public void print(){
System.out.println("Printing The Area of Rectangle :"+area());
}
}
public class Task_3{
public static void main(String []args){
Rectangle r1= new Rectangle(120.76,12.07);
r1.print();


}
}