interface Vehicle{
public void Start();
public void Stop();
}
class Car implements Vehicle{
public void Start(){
System.out.println("Car is Starting");
}
public void Stop(){
System.out.println("Car is Stoped");
}


}
class Bike implements Vehicle{
public void Start(){
System.out.println("Bike is Starting");
}
public void Stop(){
System.out.println("Bike is Stoped");
}


}
class Task_2{
public static void main(String []args){
Car c1= new Car();
Bike b1= new Bike();
b1.Start();
b1.Stop();
c1.Start();
c1.Stop();
}
} 