abstract class Animal{

abstract void makeSound();
void eat() {
System.out.println("Animal is eating");
}

}
class Dog extends Animal{
void makeSound(){
System.out.println("Dog Makes sound");}


}
class Cat extends Animal{
void makeSound(){
System.out.println("Cat Makes sound");}


}
public class Task_1{
public static void main(String []args){
Dog d1= new Dog();
Cat c1= new Cat();
d1.eat();
c1.eat();
d1.makeSound();
c1.makeSound();
}
}